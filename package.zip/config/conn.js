const mysql = require("mysql2/promise");
const startConnection = async () => {
  try {
    const conn = await mysql.createPool({
      host: "127.0.0.1",
      database: "sisdatabase2",
      user: "root",
      password: "",
    });
    console.log(" Database Connected.");
    return conn;
  } catch (error) {
    console.error(`ERRDB. - ${error.message}`);
  }
};

const endConnection = async (conn) => {
  await conn.end();
};
// const conn = mysql.createConnection({
//   host: "localhost",
//   user: "root",
//   password: "",
//   database: "sisdatabase2",
//   keepAliveInitialDelay: 10000,
//   enableKeepAlive: true
// });

// conn.connect((err) => {
//   if (err) console.log(err);
// });

module.exports = {
  startConnection,
  endConnection,
};
